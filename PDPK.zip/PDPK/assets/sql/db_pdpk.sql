-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2018 at 09:29 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pdpk`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Id_Customer` varchar(5) NOT NULL,
  `Nama_Customer` varchar(50) NOT NULL,
  `Alamat_Customer` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Id_Customer`, `Nama_Customer`, `Alamat_Customer`) VALUES
('C0001', 'PD. Elang Jaya', 'Jl. Kebon Jati, No. 44-88, Kb Jeruk, Andir, Kota Bandung'),
('C0002', 'PT. Naga Putra Sutera Mas', 'Jl. Rancaekek Km 24,5 Komp. Dwipapuri Kav B3, Linggar, Rancaekek, Bandung'),
('C0003', 'PT MUTIARA NAGA JAYA', 'Kopo Jaya 17 - Bandung'),
('C0004', 'PA DEDE', 'Jl. Tamin No. 5, Bandung'),
('C0005', 'KOSWARA', 'Jl. Toblong No. 80, Majalaya - Bandung'),
('C0006', 'KO ACONG', 'Tamin No.17, Bandung'),
('C0007', 'PA TOMMY', 'BANDUNG');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_detail_kain`
--

CREATE TABLE `tbl_detail_kain` (
  `Id_Detail_Kain` varchar(5) NOT NULL,
  `Id_Customer` varchar(5) NOT NULL,
  `Id_Kain` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_detail_kain`
--

INSERT INTO `tbl_detail_kain` (`Id_Detail_Kain`, `Id_Customer`, `Id_Kain`) VALUES
('D0001', 'C0001', 'EA-223'),
('D0002', 'C0002', 'PCK-0344_M1'),
('D0003', 'C0002', 'NRSL-3065'),
('D0004', 'C0004', 'PD-2X2'),
('D0006', 'C0006', 'AC-1580-P12'),
('D0007', 'C0003', 'MNJ-1158-P40'),
('D0008', 'C0006', 'AC-1580-P14'),
('D0009', 'C0006', 'AC-1580-P13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kain`
--

CREATE TABLE `tbl_kain` (
  `Id_Kain` varchar(30) NOT NULL,
  `Jenis_Kain` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kain`
--

INSERT INTO `tbl_kain` (`Id_Kain`, `Jenis_Kain`) VALUES
('AC-1580-P12', 'POLYESTER'),
('AC-1580-P13', 'POLYESTER'),
('AC-1580-P14', 'POLYESTER'),
('EA-223', 'CT+PE'),
('EJ 203', 'CT+PE'),
('MNJ-1158-P40', 'POLYESTER'),
('NRSL-3065', 'POLYESTER'),
('PCK-0344_M1', 'CT+PE'),
('PD-1X1', 'CT+PE'),
('PD-2X2', 'CT+PE'),
('SPC-22443456-M1', 'CT+PE');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `Id_Login` varchar(5) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`Id_Login`, `Username`, `Password`, `Level`) VALUES
('L0001', 'admin', 'admin', 'admin'),
('L0002', 'pimpinan', 'pimpinan', 'pimpinan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengiriman`
--

CREATE TABLE `tbl_pengiriman` (
  `Id_Pengiriman` varchar(7) NOT NULL,
  `Id_Detail_Kain` varchar(5) NOT NULL,
  `Tgl_Pengiriman` date NOT NULL,
  `Jml_Pengiriman` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengiriman`
--

INSERT INTO `tbl_pengiriman` (`Id_Pengiriman`, `Id_Detail_Kain`, `Tgl_Pengiriman`, `Jml_Pengiriman`) VALUES
('PG0003', 'D0003', '2018-08-22', 100),
('PG0006', 'D0007', '2018-08-22', 300),
('PG0007', 'D0003', '2018-08-22', 100),
('PG0014', 'D0006', '2018-09-07', 0),
('PG0015', 'D0007', '2018-09-07', 0),
('PG0016', 'D0009', '2018-09-18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_produksi`
--

CREATE TABLE `tbl_produksi` (
  `Id_Produksi` varchar(10) NOT NULL,
  `Id_Detail_Kain` varchar(5) NOT NULL,
  `Tgl_Produksi` date NOT NULL,
  `Jml_Produksi` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_produksi`
--

INSERT INTO `tbl_produksi` (`Id_Produksi`, `Id_Detail_Kain`, `Tgl_Produksi`, `Jml_Produksi`) VALUES
('PR0001', 'D0001', '2018-07-01', 100),
('PR0002', 'D0001', '2018-07-04', 305),
('PR0003', 'D0002', '2018-07-04', 100),
('PR0004', 'D0003', '2018-07-05', 120),
('PR0005', 'D0007', '2018-07-05', 500),
('PR0006', 'D0002', '2018-08-10', 300),
('PR0007', 'D0002', '2018-08-22', 100),
('PR0008', 'D0003', '2018-08-22', 123),
('PR0009', 'D0004', '2018-08-22', 100),
('PR0010', 'D0003', '2018-08-22', 123),
('PR0011', 'D0004', '2018-08-22', 123),
('PR0012', 'D0004', '2018-08-22', 32),
('PR0013', 'D0004', '2018-08-24', 123),
('PR0014', 'D0001', '2018-08-23', 100),
('PR0015', 'D0001', '2018-08-22', 12),
('PR0016', 'D0001', '2018-08-26', 100),
('PR0017', 'D0008', '2018-09-08', 1000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Id_Customer`);

--
-- Indexes for table `tbl_detail_kain`
--
ALTER TABLE `tbl_detail_kain`
  ADD PRIMARY KEY (`Id_Detail_Kain`),
  ADD KEY `Id_Customer` (`Id_Customer`),
  ADD KEY `Id_Kain` (`Id_Kain`);

--
-- Indexes for table `tbl_kain`
--
ALTER TABLE `tbl_kain`
  ADD PRIMARY KEY (`Id_Kain`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`Id_Login`);

--
-- Indexes for table `tbl_pengiriman`
--
ALTER TABLE `tbl_pengiriman`
  ADD PRIMARY KEY (`Id_Pengiriman`),
  ADD KEY `Id_Detail_Kain` (`Id_Detail_Kain`);

--
-- Indexes for table `tbl_produksi`
--
ALTER TABLE `tbl_produksi`
  ADD PRIMARY KEY (`Id_Produksi`),
  ADD KEY `Id_Detail_Kain` (`Id_Detail_Kain`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_detail_kain`
--
ALTER TABLE `tbl_detail_kain`
  ADD CONSTRAINT `tbl_detail_kain_ibfk_1` FOREIGN KEY (`Id_Customer`) REFERENCES `tbl_customer` (`Id_Customer`),
  ADD CONSTRAINT `tbl_detail_kain_ibfk_2` FOREIGN KEY (`Id_Kain`) REFERENCES `tbl_kain` (`Id_Kain`);

--
-- Constraints for table `tbl_pengiriman`
--
ALTER TABLE `tbl_pengiriman`
  ADD CONSTRAINT `tbl_pengiriman_ibfk_1` FOREIGN KEY (`Id_Detail_Kain`) REFERENCES `tbl_detail_kain` (`Id_Detail_Kain`);

--
-- Constraints for table `tbl_produksi`
--
ALTER TABLE `tbl_produksi`
  ADD CONSTRAINT `tbl_produksi_ibfk_1` FOREIGN KEY (`Id_Detail_Kain`) REFERENCES `tbl_detail_kain` (`Id_Detail_Kain`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
