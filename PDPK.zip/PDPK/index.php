<!DOCTYPE html>
<html lang="en">
  <head>
    <title> Aplikasi Pengolahan Data Hasil Produksi Kain </title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body class="color-back-login">

  <div class="container login">
    <div class="row boder headtop">
    <div class="col-sm-4 offset-sm-4 border border-login">
        <h2 class="text-center mt-3">Halaman Login</h2>
    
       <form method="POST" action="models/proses_login.php" class="">
         <div class="form-group row mt-5">

            <label for="Username" class="col-sm-4 col-form-label">Username</label>
            <div class=" col-sm-8">
              <input type="text" class="form-control" name="Username" id="Username" autofocus required>
            </div>
          </div>
          <div class="form-group row">
            <label for="Password" class="col-sm-4 col-form-label">Password</label>
            <div class="col-sm-8">
              <input type="password" class="form-control" name="Password" id="Password" required>
            </div>

          </div>
          <div class="row tombol">
            <div class=" ">
              <button type="submit" class="btn btn-primary " name="login">Login</button>
               <button type="submit" class="btn btn-danger " name="reset">Reset</button>
            </div>
             
          </div>

        </form>
      
    </div>
  </div>


  </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/bootstrap4/js/jquery-3.3.1.min.js"></script>
    <script src="assets/bootstrap4/js/bootstrap.min.js"></script>
  </body>
</html>