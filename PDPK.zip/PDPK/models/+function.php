<?php 
session_start();


function Cek_Login($lvl,$login,$level){
	if ( !isset($login)) {
		header("location:../index.php");
		exit;
		
	}
	if ($level!=$lvl) {
		header("location:../index.php");
		exit;
	}
	
}

function Max_ID($sql,$awal_char, $bnyk_char,$char){
	$data = $sql-> fetch_object();
	$ID = $data->maxId;
	$noUrut = (int) substr($ID, $awal_char, $bnyk_char);
	$noUrut++;
	$ID = $char . sprintf("%04s", $noUrut);
	return $ID;
}


function Alert_Hapus($delete,$nama_file,$nama_page){
	 	if ($delete>0){
			$script= "<script>
		           		alert('Data berhasil di Hapus!!')
		           		document.location.href='$nama_file.php?page=$nama_page'
		          	  </script>";
		}else{
			$script= "<script>
			           	alert('Data Gagal di Hapus!!')
			           	document.location.href='$nama_file.php?page=$nama_page'
		          	</script>";
		}
		return $script;
    }

function Alert_Hapus_Batal(){
	  $script= "<script>
            	document.location.href='#'
              	</script>";
    return $script;
}

function Hapus_Session(){
		$_SESSION['key']       = [];
		$_SESSION['tgl_awal']  = [];
		$_SESSION['tgl_akhir'] = []; 
}

 ?>