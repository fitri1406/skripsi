<?php 

 class Customer 
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Tampil_Customer($pageawal=null,$pagejumlah=null,$key=null){
		$db=$this->mysqli->conn;

		$sql="SELECT * FROM tbl_customer";

		if ( $key!=null and $pagejumlah==null ) {
			$sql .=" WHERE Id_Customer LIKE '%$key%' OR 
						   Nama_Customer LIKE '%$key%' OR
						   Alamat_Customer LIKE '%$key%'";
		}
		 if ($key!=null and $pagejumlah!=null) {
		 	$sql .=" WHERE Id_Customer LIKE '%$key%' OR 
						   Nama_Customer LIKE '%$key%' OR
						   Alamat_Customer LIKE '%$key%' 
						   LIMIT $pageawal, $pagejumlah";
		 }
		 if ($key==null and $pagejumlah!=null) {
		 	$sql .= " LIMIT $pageawal, $pagejumlah";		 
		 }
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Max_Id(){
		$db=$this->mysqli->conn;
		$sql = "SELECT max(Id_Customer) as maxId FROM tbl_customer";
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tambah_Customer($Id_Customer,$Nama_Customer,$Alamat_Customer){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_customer values('$Id_Customer','$Nama_Customer','$Alamat_Customer')";
		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}


	public function Cari_Customer($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT * FROM tbl_customer";
		if ($key!=null) {
			$sql .=" WHERE Id_Customer = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Customer($Id_Customer,$Nama_Customer,$Alamat_Customer){
		$db=$this->mysqli->conn;
		$db->query("UPDATE tbl_customer SET `Nama_Customer`='$Nama_Customer', `Alamat_Customer`='$Alamat_Customer' WHERE Id_Customer='$Id_Customer' ");

		return mysqli_affected_rows($db);		
	}

	public function Hapus_Customer($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_customer WHERE Id_Customer='$id'");

		return mysqli_affected_rows($db);
	}

	public function Cek_NM_Customer($nm_customer=null){
			$db  = $this->mysqli->conn;
			$sql = "SELECT * FROM tbl_customer";

			if ($nm_customer!=null) {
					$sql .=" WHERE Nama_Customer='$nm_customer' ";
			}

		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

 }
 
 ?>