<?php 

 class Detail_Kain
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Tampil_Detail_Kain($pageawal=null,$pagejumlah=null){
		$db=$this->mysqli->conn;

		$sql="SELECT tbl_detail_kain.Id_Detail_Kain, tbl_detail_kain.Id_Customer, tbl_customer.Nama_Customer, tbl_detail_kain.Id_Kain
			FROM tbl_kain INNER JOIN (tbl_customer INNER JOIN tbl_detail_kain ON tbl_customer.Id_Customer = tbl_detail_kain.Id_Customer) ON tbl_kain.Id_Kain = tbl_detail_kain.Id_Kain";

		if ($pagejumlah!=null) {
		$sql .=" LIMIT $pageawal, $pagejumlah";
		}
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	public function Tampil_Detail_Kain2($pageawal=null,$pagejumlah=null,$group=null,$key=null){
		$db=$this->mysqli->conn;

		$sql="SELECT tbl_detail_kain.Id_Detail_Kain, tbl_detail_kain.Id_Customer, tbl_customer.Nama_Customer, tbl_detail_kain.Id_Kain,tbl_kain.Jenis_Kain
			FROM tbl_kain INNER JOIN (tbl_customer INNER JOIN tbl_detail_kain ON tbl_customer.Id_Customer = tbl_detail_kain.Id_Customer) ON tbl_kain.Id_Kain = tbl_detail_kain.Id_Kain";

		if ($key==null and $pagejumlah==null and $group!=null ) {
		$sql .="  group BY `tbl_customer`.`Nama_Customer` ASC";
		}

		else if ($key==null and $pagejumlah!=null and $group!=null ) {
		$sql .="  ORDER BY `tbl_customer`.`Nama_Customer` ASC LIMIT $pageawal, $pagejumlah";
		}

		else if ( $key!=null and $pagejumlah==null and $group!=null ) {
			$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$key%' OR 
						   tbl_detail_kain.Id_Kain LIKE '%$key%' 
						   ORDER BY `tbl_customer`.`Nama_Customer` ASC ";
		
		}
		else if ( $key!=null and  $pagejumlah!=null and $group!=null) {
			$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$key%' OR 
						  tbl_detail_kain.Id_Kain LIKE '%$key%' 
						   ORDER BY `tbl_customer`.`Nama_Customer` ASC
						   LIMIT $pageawal, $pagejumlah ";
		}
		else if ( $key!=null and  $pagejumlah==null and $group==null) {
			$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$key%' OR 
						  tbl_detail_kain.Id_Kain LIKE '%$key%' ";
		}
		
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tambah_Detail_Kain($Id_Detail_Kain,$Id_Customer,$Id_Kain){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_detail_kain values('$Id_Detail_Kain','$Id_Customer','$Id_Kain')";
		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}

		public function Max_Id(){
		$db=$this->mysqli->conn;
		$sql = "SELECT max(Id_Detail_Kain) as maxId FROM tbl_detail_kain";
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cari_Detail_Kain($key=null){
		$db=$this->mysqli->conn;
		$sql=" SELECT tbl_detail_kain.Id_Detail_Kain, tbl_detail_kain.Id_Customer, tbl_customer.Nama_Customer, tbl_detail_kain.Id_Kain
			FROM tbl_kain INNER JOIN (tbl_customer INNER JOIN tbl_detail_kain ON tbl_customer.Id_Customer=tbl_detail_kain.Id_Customer) ON tbl_kain.Id_Kain = tbl_detail_kain.Id_Kain";
		if ($key!=null) {
			$sql .=" WHERE tbl_detail_kain.Id_Detail_Kain='".$key."'";

		}

		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	public function Cari_Detail_Kain2($key=null,$order=null){
		$db=$this->mysqli->conn;
		$sql=" SELECT tbl_detail_kain.Id_Detail_Kain, tbl_detail_kain.Id_Customer, tbl_customer.Nama_Customer, tbl_detail_kain.Id_Kain
			FROM tbl_kain INNER JOIN (tbl_customer INNER JOIN tbl_detail_kain ON tbl_customer.Id_Customer=tbl_detail_kain.Id_Customer) ON tbl_kain.Id_Kain = tbl_detail_kain.Id_Kain";
		if ($key!=null) {
			$sql .=" WHERE tbl_detail_kain.Id_Detail_Kain='".$key."'";

		}
		elseif ($order!=null) {
			$sql.=" ORDER BY tbl_detail_kain.Id_Detail_Kain ASC";
		}

		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Detail_Kain($Id_Detail_Kain,$Id_Customer,$Id_Kain){
		$db=$this->mysqli->conn;
		
		$db->query("UPDATE `tbl_detail_kain` SET `Id_Customer`='$Id_Customer', `Id_Kain`='$Id_Kain' WHERE `Id_Detail_Kain`='$Id_Detail_Kain' ");

		return mysqli_affected_rows($db);		
	}

public function Hapus_Detail_Kain($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_detail_kain WHERE Id_Detail_Kain='$id'");

		return mysqli_affected_rows($db);
	}

 }

?>