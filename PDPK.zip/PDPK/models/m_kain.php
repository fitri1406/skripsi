<?php 

 class Kain
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Tampil_Kain($pageawal=null,$pagejumlah=null,$key=null){
		$db=$this->mysqli->conn;

		$sql="SELECT * FROM tbl_kain";

		if ( $key!=null and $pagejumlah==null ) {
			$sql .=" WHERE Id_Kain LIKE '%$key%' OR 
						   Jenis_Kain LIKE '%$key%'";
		}
		 if ($key!=null and $pagejumlah!=null) {
		 	$sql .=" WHERE Id_Kain LIKE '%$key%' OR 
						   Jenis_Kain LIKE '%$key%' 
						   LIMIT $pageawal, $pagejumlah";
		 }
		 if ($key==null and $pagejumlah!=null) {
		 	$sql .= " LIMIT $pageawal, $pagejumlah";		 
		 }
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tambah_Kain($Id_Kain,$Jenis_Kain){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_Kain values('$Id_Kain','$Jenis_Kain')";
		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}

	public function Cari_Kain($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT * FROM tbl_kain";
		if ($key!=null) {
			$sql .=" WHERE Id_Kain = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Kain($id_kain,$jenis_kain){
		$db=$this->mysqli->conn;
		$db->query("UPDATE tbl_kain SET Jenis_Kain='$jenis_kain' WHERE Id_Kain='$id_kain' ");

		return mysqli_affected_rows($db);		
	}

	public function Hapus_Kain($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_kain WHERE Id_Kain='$id'");

		return mysqli_affected_rows($db);
	}

	public function Cek_Id_Kain($id_kain=null){
			$db  = $this->mysqli->conn;
			$sql = "SELECT * FROM tbl_kain";

			if ($id_kain!=null) {
					$sql .=" WHERE Id_Kain='$id_kain' ";
			}

		$query = $db->query($sql) or die ($db->error);
		return $query;
	}

 }

 ?>