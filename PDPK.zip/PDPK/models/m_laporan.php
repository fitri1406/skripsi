<?php 
ob_start();
 class Laporan
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}
	public function Tampil_Laporan($pageawal=null,$pagejumlah=null){
		$db=$this->mysqli->conn;

		$sql="SELECT * FROM tbl_Laporan";

		if ($pagejumlah!=null) {
		$sql .=" LIMIT $pageawal, $pagejumlah";
		}
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tampil_Laporan_Produksi_Pengiriman($pageawal=null,$pagejumlah=null){
		$db=$this->mysqli->conn;

		$sql="SELECT * FROM tbl_Laporan";

		if ($pagejumlah!=null) {
		$sql .=" LIMIT $pageawal, $pagejumlah";
		}
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	public function Tambah_Laporan($Id_Detail_Kain,$Kode,$Tanggal,$Jumlah,$Stok,$Keterangan){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_laporan values('','$Id_Detail_Kain','$Kode','$Tanggal','$Jumlah','$Stok','$Keterangan')";

		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}

		public function Max_Id(){
		$db=$this->mysqli->conn;
		$sql = "SELECT max(Id_Laporan) as maxId FROM tbl_Laporan";
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cari_Laporan($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT * FROM tbl_Laporan";
		if ($key!=null) {
			$sql .=" WHERE Id_Laporan = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	public function Cari_Laporan_Detail($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT Stok FROM tbl_laporan";
		if ($key!=null) {
			$sql .=" WHERE Id_Detail_Kain = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Laporan($Id_Laporan,$Id_Detail_Kain,$Tgl_Laporan,$Jml_Laporan){
		$db=$this->mysqli->conn;
		
		$db->query("UPDATE `tbl_Laporan` SET `Id_Detail_Kain`='$Id_Detail_Kain', `Tgl_Laporan`='$Tgl_Laporan',`Jml_Laporan`='$Jml_Laporan' WHERE `Id_Laporan`='$Id_Laporan' ");

		return mysqli_affected_rows($db);		
	}

public function Hapus_Laporan($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_Laporan WHERE Id_Laporan='$id'");

		return mysqli_affected_rows($db);

	}

	public function Melihat_Laporan($key=null, $tgl_awal=null, $tgl_akhir=null,
									$awal_data=null,$jml_halaman=null,$group=null){
		$db=$this->mysqli->conn;
		
	$sql= "SELECT tbl_detail_kain.Id_Detail_Kain,tbl_customer.Nama_Customer,tbl_kain.Id_Kain,tbl_produksi.Tgl_Produksi,SUM(tbl_produksi.Jml_Produksi) AS Total_Produksi,Total_Pengiriman, perg.Tgl_Pengiriman 
		FROM (tbl_kain INNER JOIN (tbl_customer INNER JOIN tbl_Detail_Kain ON tbl_customer.Id_Customer = tbl_Detail_Kain.Id_Customer) ON tbl_kain.Id_Kain = tbl_Detail_Kain.Id_Kain)  INNER JOIN tbl_produksi ON tbl_Detail_Kain.Id_Detail_Kain = tbl_produksi.Id_Detail_Kain 
		INNER JOIN
		(SELECT tbl_detail_kain.Id_Detail_Kain,SUM(tbl_pengiriman.Jml_Pengiriman) AS Total_Pengiriman,tbl_pengiriman.Tgl_Pengiriman FROM tbl_detail_kain,tbl_pengiriman WHERE tbl_detail_kain.Id_Detail_Kain=tbl_pengiriman.Id_Detail_Kain GROUP BY tbl_pengiriman.Id_Detail_Kain) AS perg ON tbl_detail_kain.Id_Detail_Kain=perg.Id_Detail_Kain";


		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null AND $group!=null) {
			$sql .=" GROUP BY tbl_detail_kain.Id_Detail_Kain";
		
		}

		if ($key==null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $group!=null){
			$sql .=" GROUP BY tbl_detail_kain.Id_Detail_Kain LIMIT $awal_data,$jml_halaman ";

		}

		if($key==null AND  $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman!=null and $group!=NULL){

			$sql.= " WHERE (tbl_produksi.Tgl_Produksi >= '$tgl_awal' AND tbl_produksi.Tgl_Produksi <= '$tgl_akhir') 
				AND (perg.Tgl_Pengiriman >= '$tgl_awal' AND perg.Tgl_Pengiriman <='$tgl_akhir')
				GROUP BY tbl_detail_kain.Id_Detail_Kain";

		}

		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman==null and $group==NULL){

			$sql .=" Where tbl_detail_kain.Id_Detail_Kain='$key'";
		
		}

		if ($key!=null AND $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman==null and $group==NULL){

			$sql .=" WHERE (tbl_produksi.Tgl_Produksi >= '$tgl_awal' AND tbl_produksi.Tgl_Produksi <= '$tgl_akhir') 
			AND (perg.Tgl_Pengiriman >= '$tgl_awal' AND perg.Tgl_Pengiriman <='$tgl_akhir')
			 and tbl_detail_kain.Id_Detail_Kain='$key'";

		}

		if ($key!=null AND  $tgl_awal==null AND $tgl_akhir==null AND $jml_halaman!=null AND $group==null){

		$sql .=" Where tbl_detail_kain.Id_Detail_Kain='$key' LIMIT $awal_data,$jml_halaman" ;
	
		}
		if ($key!=null AND $tgl_awal!=null AND $tgl_akhir!=null AND $jml_halaman!=null AND $group!=null){
			$sql.=" WHERE (tbl_produksi.Tgl_Produksi >= '$tgl_awal' AND tbl_produksi.Tgl_Produksi <= '$tgl_akhir') 
			AND (perg.Tgl_Pengiriman >= '$tgl_awal' AND perg.Tgl_Pengiriman <='$tgl_akhir') 
			AND (tbl_detail_kain.Id_Detail_Kain='$key') LIMIT $awal_data,$jml_halaman";
		}			
	$query= $db->query($sql) or die ($db->error);
	return $query;
	}
 }
ob_end_flush();
?>