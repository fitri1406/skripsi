<?php 

class Login
{
	
	private $mysqli;

	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Cek_Login($user=null,$pass=null){
		$db  = $this->mysqli->conn;
		$sql = "SELECT * FROM tbl_login";

		if ($user!=null and $pass!=null) {
				$sql .=" WHERE Username='$user' and Password='$pass'";
		}

		$query = $db->query($sql) or die ($db->error);
		return $query;
	}
}

 ?>