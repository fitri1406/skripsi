<?php 

 class Pengiriman
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}
	public function Tampil_Pengiriman($pageawal=null,$pagejumlah=null,$key=null,$keycari=null,$group=null){
		$db=$this->mysqli->conn;

		$sql="SELECT tbl_pengiriman.Id_Pengiriman,tbl_Detail_Kain.Id_Detail_Kain, tbl_pengiriman.Tgl_Pengiriman, tbl_customer.Nama_Customer, tbl_Kain.Id_Kain, tbl_pengiriman.Jml_Pengiriman
			FROM tbl_Kain INNER JOIN (tbl_customer INNER JOIN (tbl_Detail_Kain INNER JOIN tbl_pengiriman ON tbl_Detail_Kain.ID_Detail_Kain = tbl_pengiriman.Id_Detail_Kain) ON tbl_customer.Id_Customer = tbl_Detail_Kain.Id_Customer) ON tbl_Kain.Id_Kain = tbl_Detail_Kain.ID_Kain";

	if ($pagejumlah!=null AND $keycari==null AND $key==null) {
		$sql .=" LIMIT $pageawal, $pagejumlah";
		}

		elseif ($key!=null AND $pagejumlah==null) {
			$sql.= " WHERE tbl_pengiriman.Id_Pengiriman ='$key'";
		}

		elseif ($pagejumlah!=null AND $key==null AND $keycari!=null) {
		$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$keycari%' LIMIT $pageawal,$pagejumlah";
		}
		elseif ($pagejumlah==null AND $key==null AND $keycari!=null) {
		$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$keycari%' ";
		}

		elseif ($group!=null) {
		$sql .= " GROUP BY tbl_customer.Nama_Customer";
		}
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	public function Tambah_Pengiriman($Id_Pengiriman,$Id_Detail_Kain,$Tgl_Pengiriman,$Jml_Pengiriman){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_Pengiriman values('$Id_Pengiriman','$Id_Detail_Kain','$Tgl_Pengiriman',
				'$Jml_Pengiriman')";
				// var_dump($Tgl_Pengiriman);
		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}
		public function Max_Id(){
		$db=$this->mysqli->conn;
		$sql = "SELECT max(Id_Pengiriman) as maxId FROM tbl_pengiriman";
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cari_Pengiriman($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT * FROM tbl_Pengiriman";
		if ($key!=null) {
			$sql .=" WHERE Id_Pengiriman = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Pengiriman($Id_Pengiriman,$Id_Detail_Kain,$Tgl_Pengiriman,$Jml_Pengiriman){
		$db=$this->mysqli->conn;
		
		$db->query("UPDATE `tbl_Pengiriman` SET `Id_Detail_Kain`='$Id_Detail_Kain', `Tgl_Pengiriman`='$Tgl_Pengiriman',`Jml_Pengiriman`='$Jml_Pengiriman' WHERE `Id_Pengiriman`='$Id_Pengiriman' ");

		return mysqli_affected_rows($db);		
	}

public function Hapus_Pengiriman($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_Pengiriman WHERE Id_Pengiriman='$id'");

		return mysqli_affected_rows($db);

	}
	public function Hapus_Pengiriman_Detail($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_Pengiriman WHERE Id_Detail_Kain='$id'");

		return mysqli_affected_rows($db);
	}

public function Total_Pengiriman($id=null){

	$db=$this->mysqli->conn;
	$sql = "SELECT SUM(Jml_Pengiriman) AS Total_Pengiriman FROM tbl_pengiriman WHERE Id_Detail_Kain='$id' ";

	$query= $db->query($sql) or die ($db->error);
	return $query;
}

 }

?>