<?php 

 class Produksi
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}

	public function Tampil_Produksi($pageawal=null,$pagejumlah=null,$key=null,$keycari=null,$group=null){
		$db=$this->mysqli->conn;

		$sql="SELECT tbl_produksi.Id_Produksi,tbl_Detail_Kain.Id_Detail_Kain, tbl_produksi.Tgl_Produksi, tbl_customer.Nama_Customer, tbl_Kain.Id_Kain, tbl_produksi.Jml_Produksi
			FROM tbl_Kain INNER JOIN (tbl_customer INNER JOIN (tbl_Detail_Kain INNER JOIN tbl_produksi ON tbl_Detail_Kain.ID_Detail_Kain = tbl_produksi.Id_Detail_Kain) ON tbl_customer.Id_Customer = tbl_Detail_Kain.Id_Customer) ON tbl_Kain.Id_Kain = tbl_Detail_Kain.ID_Kain";

		if ($pagejumlah!=null AND $keycari==null AND $key==null) {
		$sql .=" LIMIT $pageawal, $pagejumlah";
		}

		elseif ($key!=null AND $pagejumlah==null) {
			$sql.= " WHERE tbl_produksi.Id_Produksi ='$key'";
		}

		elseif ($pagejumlah!=null AND $key==null AND $keycari!=null) {
		$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$keycari%' LIMIT $pageawal,$pagejumlah";
		}
		elseif ($pagejumlah==null AND $key==null AND $keycari!=null) {
		$sql .=" WHERE tbl_customer.Nama_Customer LIKE '%$keycari%' ";
		}

		elseif ($group!=null) {
		$sql.= " GROUP BY tbl_customer.Nama_Customer";
		}
	
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Tambah_Produksi($Id_Produksi,$Id_Detail_Kain,$Tgl_Produksi,$Jml_Produksi){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_produksi values('$Id_Produksi','$Id_Detail_Kain','$Tgl_Produksi',
				'$Jml_Produksi')";
		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}

		public function Max_Id(){
		$db=$this->mysqli->conn;
		$sql = "SELECT max(Id_Produksi) as maxId FROM tbl_produksi";
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cari_Produksi($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT * FROM tbl_produksi";
		if ($key!=null) {
			$sql .=" WHERE Id_Produksi = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Produksi($Id_Produksi,$Id_Detail_Kain,$Tgl_Produksi,$Jml_Produksi){
		$db=$this->mysqli->conn;
		
		$db->query("UPDATE `tbl_produksi` SET `Id_Detail_Kain`='$Id_Detail_Kain', `Tgl_Produksi`='$Tgl_Produksi',`Jml_Produksi`='$Jml_Produksi' WHERE `Id_Produksi`='$Id_Produksi' ");

		return mysqli_affected_rows($db);		
	}

public function Hapus_Produksi($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_Produksi WHERE Id_Produksi='$id'");

		return mysqli_affected_rows($db);
	}

public function Total_Produksi($key=null){

	$db=$this->mysqli->conn;
	$sql = "SELECT SUM(Jml_Produksi) AS Total_Produksi FROM tbl_produksi WHERE Id_Detail_Kain='$key' ";
				
	$query= $db->query($sql) or die ($db->error);
	return $query;

	}
 }
 
?>