<?php 

 class Stok
 {
 	private $mysqli;
	
	function __construct($conn)
	{
		$this->mysqli= $conn;
	}


	public function Tampil_Stok($pageawal=null,$pagejumlah=null){
		$db=$this->mysqli->conn;

		$sql="SELECT * FROM tbl_Stok";

		if ($pagejumlah!=null) {
		$sql .=" LIMIT $pageawal, $pagejumlah";
		}
	
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}


	public function Tambah_Stok_Produksi($Id_Stok,$Id_Detail_Kain,$Tgl,$Produksi,$Pengiriman,$Stok){
		$db=$this->mysqli->conn;
		$sql="INSERT INTO tbl_stok values('','$Id_Detail_Kain','$Tgl','$Produksi','$Pengiriman','$Stok')";
		$query= $db->query($sql);		
		return mysqli_affected_rows($db);
	}

		public function Max_Id(){
		$db=$this->mysqli->conn;
		$sql = "SELECT max(Id_Stok) as maxId FROM tbl_Stok";
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Cari_Stok($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT * FROM tbl_stok";
		if ($key!=null) {
			$sql .=" WHERE Id_Stok = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}
	public function Cari_Stok_Detail($key=null){
		$db=$this->mysqli->conn;
		$sql="SELECT Stok FROM tbl_stok";
		if ($key!=null) {
			$sql .=" WHERE Id_Detail_Kain = '$key'";
		}
		$query= $db->query($sql) or die ($db->error);
		return $query;
	}

	public function Update_Stok($Id_Stok,$Id_Detail_Kain,$Tgl_Stok,$Jml_Stok){
		$db=$this->mysqli->conn;
		
		$db->query("UPDATE `tbl_Stok` SET `Id_Detail_Kain`='$Id_Detail_Kain', `Tgl_Stok`='$Tgl_Stok',`Jml_Stok`='$Jml_Stok' WHERE `Id_Stok`='$Id_Stok' ");

		return mysqli_affected_rows($db);		
	}

public function Hapus_Stok($id){
		$db=$this->mysqli->conn;
		$db->query("DELETE FROM tbl_Stok WHERE Id_Stok='$id'");

		return mysqli_affected_rows($db);

	}


 }//end class


?>