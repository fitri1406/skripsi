<?php 
include_once "+function.php";
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_login.php";

$connection = new Database($host, $user, $pass, $database);
$login       = new Login($connection);

$username   = $_POST['Username'];
$password   = $_POST['Password'];

$data       = $login->Cek_Login($username, $password);							
	if (mysqli_num_rows($data)===1) {
		$cek=$data->fetch_object();
		if ($cek->Level=='admin') {
			$_SESSION["login"] = true;
			$_SESSION["admin"]  = $cek->Username;
			$_SESSION["level"] = $cek->Level;
			header("location:../views/home_pdpk.php");
		}
		else if ($cek->Level=='pimpinan') {
			$_SESSION["login"] = true;
			$_SESSION["pimpinan"]  = $cek->Username;
			$_SESSION["level"] = $cek->Level;
			header("location:../views/home_pdpk_pimpinan.php");
		}	
	}
	else{
		echo "<script>
		        alert('Username atau Password anda salah !!')
		        document.location.href='../index.php'
		       </script>";
		}

 ?>