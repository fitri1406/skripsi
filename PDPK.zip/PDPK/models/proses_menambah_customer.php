<?php 
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_customer.php";
$connection= new Database($host, $user, $pass, $database); 
$Customer= new Customer($connection);


if (isset($_POST['simpan'])) {
	$Id_Customer=$connection->conn->real_escape_string($_POST['Id_Customer']);
	$Nama_Customer=$connection->conn->real_escape_string($_POST['Nama_Customer']);
	$Alamat_Customer=$connection->conn->real_escape_string($_POST['Alamat_Customer']);

	$db=$Customer->Tambah_Customer($Id_Customer,$Nama_Customer,$Alamat_Customer);

	if ($db>0) {
		echo "<script>
		           	alert('Data berhasil di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=customer'
		          </script>";
		}else{
			echo "<script>
		           	alert('Data Gagal di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=menambah_customer'
		          </script>";
		}

}




 ?>