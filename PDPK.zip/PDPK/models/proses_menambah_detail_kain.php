<?php 
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_detail_kain.php";
include "m_pengiriman.php";
include "+function.php";
$connection= new Database($host, $user, $pass, $database); 
$Detail_Kain= new Detail_Kain($connection);
$Pengiriman= new Pengiriman($connection);
$maxID=$Pengiriman->Max_Id();
$ID=Max_Id($maxID,2,5,'PG');


if (isset($_POST['simpan'])) {
	
	$Id_Detail_Kain=$connection->conn->real_escape_string($_POST['Id_Detail_Kain']);
	$Id_Customer=$connection->conn->real_escape_string($_POST['Nama_Customer']);
	$Id_Kain=$connection->conn->real_escape_string($_POST['Id_Kain']);
	$tgl=date("Y-m-d");
	$db=1;
	// var_dump($tgl);
	$db=$Detail_Kain->Tambah_Detail_Kain($Id_Detail_Kain,$Id_Customer,$Id_Kain);

	if ($db>0) {
		$db_pengiriman=$Pengiriman->Tambah_Pengiriman($ID,$Id_Detail_Kain,$tgl,0);
		// var_dump($db_pengiriman);
		if ($db_pengiriman<0) {
			echo "<script>
		           	alert('Data Pengiriman Gagal di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=menambah_detail_kain'
		          </script>";
		}
		echo "<script>
		           	alert('Data berhasil di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=detail_kain'
		          </script>";
		}else{
			echo "<script>
		           	alert('Data Gagal di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=menambah_detail_kain'
		          </script>";
		}

}




 ?>