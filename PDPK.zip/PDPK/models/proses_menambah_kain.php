<?php 
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_kain.php";
$connection= new Database($host, $user, $pass, $database); 
$Kain= new Kain($connection);


if (isset($_POST['simpan'])) {
	$Id_Kain=$connection->conn->real_escape_string($_POST['Id_Kain']);
	$Jenis_Kain=$connection->conn->real_escape_string($_POST['Jenis_Kain']);

	$db=$Kain->Tambah_Kain($Id_Kain,$Jenis_Kain);

	if ($db>0) {
		echo "<script>
		           	alert('Data berhasil di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=kain'
		          </script>";
		}else{
			echo "<script>
		           	alert('Data Gagal di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=menambah_kain'
		          </script>";
		}

}




 ?>