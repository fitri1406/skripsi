<?php 
require_once("../config/+koneksi.php");
require_once("database.php");
include "m_pengiriman.php";
include "m_laporan.php";
include "m_produksi.php";
$connection= new Database($host, $user, $pass, $database); 
$Pengiriman= new Pengiriman($connection);
$Laporan= new Laporan($connection);
$Produksi= new Produksi($connection);

if (isset($_POST['simpan'])) { 
	
	$Id_Pengiriman=$connection->conn->real_escape_string($_POST['Id_Pengiriman']);
	$Tgl_Pengiriman=$connection->conn->real_escape_string($_POST['Tgl_Pengiriman']);	
	$Id_Detail_Kain=$connection->conn->real_escape_string($_POST['Id_Detail_Kain']);
	$Jml_Pengiriman=$connection->conn->real_escape_string($_POST['Jml_Pengiriman']);

	$Total_Pengiriman= $Pengiriman->Total_Pengiriman($Id_Detail_Kain);
	$Total_Produksi = $Produksi->Total_Produksi($Id_Detail_Kain);
	while ($Data_Pengiriman=$Total_Pengiriman->fetch_object() and 
			$Data_Produksi=$Total_Produksi->fetch_object()) {
                  $Data_Produksi=$Data_Produksi->Total_Produksi; 
                  $Data_Pengiriman=$Data_Pengiriman->Total_Pengiriman;  
                  $Stok_Awal=$Data_Produksi-$Data_Pengiriman;
              }

	if ($Stok_Awal-$Jml_Pengiriman<0) {
		echo "<script>
				alert('Data Jumlah Pengiriman melebihi Data Stok!!!!')
				   	document.location.href='../views/home_pdpk.php?page=menambah_pengiriman'
				</script>";
	}else{
			$Res_Pengiriman=$Pengiriman->Tambah_Pengiriman($Id_Pengiriman,$Id_Detail_Kain,$Tgl_Pengiriman,$Jml_Pengiriman);

			if ($Res_Pengiriman>0) {			

				echo "<script>
				           	alert('Data berhasil di simpan!!')
				           	document.location.href='../views/home_pdpk.php?page=pengiriman'
				          </script>";
			}else{
				echo "<script>
			           	alert('Data Gagal di simpan!!')
			           	document.location.href='../views/home_pdpk.php?page=menambah_pengiriman'
			          </script>";
			}
		}
}

 ?>