<?php 

require_once("../config/+koneksi.php");
require_once("database.php");
include "m_produksi.php";
include "m_pengiriman.php";
include "m_stok.php";
include "m_laporan.php";
$connection= new Database($host, $user, $pass, $database); 
$Produksi= new Produksi($connection);
$Stok= new Stok($connection);
$Laporan = new Laporan($connection);
$Pengiriman = new Pengiriman($connection);

if (isset($_POST['simpan'])) {
	
	$Id_Produksi=$connection->conn->real_escape_string($_POST['Id_Produksi']);
	$Tgl_Produksi=$connection->conn->real_escape_string($_POST['Tgl_Produksi']);	
	$Id_Detail_Kain=$connection->conn->real_escape_string($_POST['Id_Detail_Kain']);
	$Jml_Produksi=$connection->conn->real_escape_string($_POST['Jml_Produksi']);

	$Res_Produksi=$Produksi->Tambah_Produksi($Id_Produksi,$Id_Detail_Kain,$Tgl_Produksi,$Jml_Produksi);
	if ($Res_Produksi>0) {
		echo "<script>
		           	alert('Data berhasil di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=produksi'
		          </script>";
		}else{
			echo "<script>
		           	alert('Data Gagal di simpan!!')
		           	document.location.href='../views/home_pdpk.php?page=menambah_produksi'
		          </script>";
		}
}

 ?>