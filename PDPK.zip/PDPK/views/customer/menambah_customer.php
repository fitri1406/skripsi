<?php 
include_once "../models/+function.php";
include "../models/m_customer.php";
$Customer = new Customer($connection);
$maxID=$Customer->Max_Id();
$ID=Max_Id($maxID,1,5,'C');
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);//$sql,$awal_char, $bnyk_char,$char-untuk

?>

<div class="container form-input">
  <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Menambah Data Customer</h4>
      <hr>
    </div>
  </div>
  <form method="POST" action="../models/proses_menambah_customer.php">
    <div class="form-group row">
      <label for="Id_Customer" class="col-sm-2 offset-sm-3 col-form-label">Id Customer</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Customer" id="Id_Customer" value="<?php echo "$ID"; ?>" required>
      </div>
    </div>
    <div class="form-group row">
      <label for="Nama_Customer" class="col-sm-2 offset-sm-3 col-form-label">Nama Customer</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Nama_Customer" id="Nama_Customer" required>
      </div>
    </div>
    <div class="form-group row">
      <label for="Alamat_Customer" class="col-sm-2 offset-sm-3 col-form-label">Alamat Customer</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Alamat_Customer" id="Alamat_Customer" required>
      </div>
    </div>

    <div class="row tombol">
      <div class="col offset-sm-5">
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="reset" class="btn btn-danger" name="batal">Batal</button>
      </div>
       
    </div>

  </form>
</div>