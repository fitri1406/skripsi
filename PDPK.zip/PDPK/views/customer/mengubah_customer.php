<?php 
include_once "../models/+function.php";
include "../models/m_customer.php";
$Customer = new Customer($connection);
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$id=$_GET['ID'];
$sql=$Customer->Cari_Customer($id);
while ($data=$sql->fetch_object()) {
		$Id_Customer=$data->Id_Customer;	
		$Nama_Customer=$data->Nama_Customer;
    $Alamat_Customer=$data->Alamat_Customer;
		
	}

?>

<div class="container form-input">
  <form method="POST" action="">
   <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Mengubah Data Customer</h4>
      <hr>
    </div>
  </div>
    <div class="form-group row">
      <label for="Id_Customer" class="col-sm-2 offset-sm-3 col-form-label">Id Customer</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Customer" id="Id_Customer" value="<?php echo "$Id_Customer"; ?>" required>
      </div>
    </div>
    <div class="form-group row ">
      <label for="Nama_Customer" class="col-sm-2 offset-sm-3 col-form-label">Nama Customer</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Nama_Customer" id="Nama_Customer" required value="<?php echo "$Nama_Customer"; ?>">
      </div>
    </div>
    <div class="form-group row ">
      <label for="Alamat_Customer" class="col-sm-2 offset-sm-3 col-form-label">Alamat Customer</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Alamat_Customer" id="Alamat_Customer" required value="<?php echo "$Alamat_Customer"; ?>">
      </div>
    </div>
    <div class="row tombol">
        <div class="col offset-sm-5">
          <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
          <button type="reset" class="btn btn-danger" name="batal">Batal</button>
        </div>
    </div>

  </form>
</div>



<?php 
if (isset($_POST['simpan'])) {
	
	$id_cust=$connection->conn->real_escape_string($_POST['Id_Customer']);
    $nm_cust=$connection->conn->real_escape_string($_POST['Nama_Customer']); 
    $alamat_cust=$connection->conn->real_escape_string($_POST['Alamat_Customer']);   
          
        
        
    $update=$Customer->Update_Customer($id_cust,$nm_cust,$alamat_cust);
    if ($update>0){
		echo "<script>
		     	alert('Data berhasil di Update!!')
		       	document.location.href='home_pdpk.php?page=customer'
		      </script>";
	}else{
		echo "<script>
	           	alert('Data Gagal di Update!!')
	           	document.location.href='home_pdpk.php?page=mengubah_customer&ID=$id_cust'
	          </script>";
	}

	
}

 ?>