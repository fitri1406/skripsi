<?php 
include_once "../models/+function.php";
include "../models/m_detail_kain.php";
include "../models/m_customer.php";
include "../models/m_kain.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$Detail_Kain = new Detail_Kain($connection);
$Customer = new Customer($connection);
$Kain = new Kain($connection);


$Cek_Customer = $Customer->Cek_NM_Customer();
$Cek_Kain = $Kain->Cek_Id_Kain();

$maxID=$Detail_Kain->Max_Id();
$ID=Max_Id($maxID,1,5,'D');//$sql,$awal_char, $bnyk_char,$char-untuk



?>

<div class="container form-input">
  <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Menambah Data Detail Kain</h4>
      <hr>
    </div>
  </div>
  <form method="POST" action="../models/proses_menambah_detail_kain.php">
    <div class="form-group row">
      <label for="Id_Detail_Kain" class="col-sm-2 offset-sm-3 col-form-label">Id Detail</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Detail_Kain" id="Id_Detail_Kain" value="<?php echo "$ID"; ?>" required>
      </div>
    </div>

    <div class="form-group row">
        <label for="Nama_Customer" class="col-sm-2 offset-sm-3 col-form-label ">Nama Customer</label>
            <div class="col-sm-4">
              <select class="custom-select" name="Nama_Customer" id="Nama_Customer" required>
              <option value=""> -- Silahkan Pilih  -- </option>
                <?php while ($data_customer=$Cek_Customer->fetch_object()) :
                ?>
              <option value="<?php echo $data_customer->Id_Customer; ?>"><?php echo $data_customer->Nama_Customer; ?></option>
                <?php 
                endwhile;
                ?>
            </select>
            </div>            
        </div>

        <div class="form-group row">
        <label for="Id_Kain" class="col-sm-2 offset-sm-3 col-form-label ">Id Kain</label>
            <div class="col-sm-4">
              <select class="custom-select" name="Id_Kain" id="Id_Kain" required>
              <option value=""> -- Silahkan Pilih  -- </option>
                <?php while ($data_kain=$Cek_Kain->fetch_object()) :
                ?>
              <option value="<?php echo $data_kain->Id_Kain; ?>"><?php echo $data_kain->Id_Kain; ?></option>
                <?php 
                endwhile;
                ?>
            </select>
            </div>            
        </div>


    </div>
    <div class="row tombol">
      <div class="col offset-sm-5">
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="reset" class="btn btn-danger" name="batal">Batal</button>
      </div>
       
    </div>

  </form>
</div>