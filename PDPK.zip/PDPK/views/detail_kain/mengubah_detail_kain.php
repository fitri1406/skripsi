<?php 
include_once "../models/+function.php";
include "../models/m_detail_kain.php";
include "../models/m_customer.php";
include "../models/m_kain.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$Detail_Kain = new Detail_Kain($connection);
$Customer = new Customer($connection);
$Kain = new Kain($connection);
$id=$_GET['ID'];
$sql=$Detail_Kain->Cari_Detail_Kain($id);
$Cek_Customer=$Customer->Cek_NM_Customer();
$Cek_Kain = $Kain->Cek_Id_Kain();
while ($data=$sql->fetch_object()) {
		$Id_Detail_Kain=$data->Id_Detail_Kain;	
    $Id_Customer=$data->Id_Detail_Kain;
 		$Id_Kain=$data->Id_Kain;
    $Nama_Customer = $data->Nama_Customer;

	}

?>

<div class="container form-input">
  <form method="POST" action="">
   <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Mengubah Data Detail Kain</h4>
      <hr>
    </div>
  </div>
    <div class="form-group row">
      <label for="Id_Detail_Kain" class="col-sm-2 offset-sm-3 col-form-label">Id Detail Kain</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Detail_Kain" id="Id_Detail_Kain" value="<?php echo "$Id_Detail_Kain"; ?>" required>
      </div>
    </div>
    <div class="form-group row">
        <label for="Nama_Customer" class="col-sm-2 offset-sm-3 col-form-label ">Nama Customer</label>
            <div class="col-sm-4">
              <select class="custom-select" name="Nama_Customer" id="Nama_Customer" required>
            <option value=""> -- Silahkan Pilih  -- </option>
              <?php 
              while ($data_customer=$Cek_Customer->fetch_object()) :            
              ?>
            <option value="<?php echo $data_customer->Id_Customer;?>" 
                <?php 
                  if ($data_customer->Nama_Customer==$Nama_Customer) { echo "selected=\"selected\"";}
                ?> ><?php echo "$data_customer->Nama_Customer";?>  
            </option>
              <?php 
              endwhile;
              ?>
          </select>
            </div>            
        </div>
        <div class="form-group row">
        <label for="Id_Kain" class="col-sm-2 offset-sm-3 col-form-label ">Id Kain</label>
            <div class="col-sm-4">
              <select class="custom-select" name="Id_Kain" id="Id_Kain" required>
            <option value=""> -- Silahkan Pilih  -- </option>
              <?php 
              while ($data_kain=$Cek_Kain->fetch_object()) :            
              ?>
            <option value="<?php echo $data_kain->Id_Kain;?>" 
                <?php 
                  if ($data_kain->Id_Kain==$Id_Kain) { echo "selected=\"selected\"";}
                ?> ><?php echo "$data_kain->Id_Kain";?>  
            </option>
              <?php 
              endwhile;
              ?>
          </select>
            </div>            
        </div>
    <div class="row tombol">
        <div class="col offset-sm-5">
          <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
          <button type="reset" class="btn btn-danger" name="batal">Batal</button>
        </div>
    </div>

  </form>
</div>



<?php 
if (isset($_POST['simpan'])) {
	
	  $Id_Detail_Kain=$connection->conn->real_escape_string($_POST['Id_Detail_Kain']);
    $Id_Customer=$connection->conn->real_escape_string($_POST['Nama_Customer']); 
    $Id_Kain=$connection->conn->real_escape_string($_POST['Id_Kain']); 

   
        
    $update=$Detail_Kain->Update_Detail_Kain($Id_Detail_Kain,$Id_Customer,$Id_Kain);
    if ($update>0){
		echo "<script>
		     	alert('Data berhasil di Update!!')
		       	document.location.href='home_pdpk.php?page=detail_kain'
		      </script>";
	}else{
		echo "<script>
	           	alert('Data Gagal di Update!!')
	           	document.location.href='home_pdpk.php?page=mengubah_detail_kain&ID=$Id_Detail_Kain'
	          </script>";
	}

	
}

 ?>