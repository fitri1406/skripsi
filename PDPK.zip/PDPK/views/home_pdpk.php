<?php 
include_once "../models/+function.php";
require_once("../config/+koneksi.php");
require_once("../models/database.php");
$connection= new Database($host, $user, $pass, $database);
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title> Aplikasi Pengolahan Data Hasil Produksi Kain </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../assets/bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body>

  <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <div class="row">
          <div class="col-sm-1 offset-1 mr-0"><img src="../assets/pic/logo 3m.JPG" class="rounded  logo" alt="logo"></div>
          <div class="col-sm"><h1 class="display-3">APLIKASI PENGOLAHAN DATA HASIL PRODUKSI KAIN <br>
          PT MULIA MEGAH MANDIRI</h1></div>
        </div>       
      </div>
  </div>
<nav class="navbar navbar-expand-lg navbar-light menu" style="background-color: #e3f2fd;">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav menu">
      <li class="nav-item active">
        <a class="nav-link" href="?page=home">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=customer">Customer</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=kain">Kain</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=detail_kain">Detail Kain</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=produksi">Produksi</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=pengiriman">Pengiriman</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=laporan">Melihat Laporan</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="?page=logout">Logout</a>
      </li>
    </ul>
  </div>
</nav>

<?php 
  if (@$_GET['page'] == 'home' or  @$_GET['page'] == '') {
     ?>
  <h1 align="center" class="selamat-datang"> Selamat Datang di Halaman Admin</h1>
  <?php
      }
          else if (@$_GET['page'] == 'logout') {
                    echo "<script>
                      alert('Berhasil Logout, Terimakasih')
                      document.location.href='../index.php'
                    </script>"; 
                    $_SESSION=[];
                    session_unset();
                    session_destroy();             
                 }

  elseif (@$_GET['page'] == 'customer') {
    include "customer/melihat_customer.php";
  }
    elseif (@$_GET['page'] == 'menambah_customer') {
    include "customer/menambah_customer.php";
  }
  elseif (@$_GET['page'] == 'mengubah_customer') {
    include "customer/mengubah_customer.php";
  }

  elseif (@$_GET['page'] == 'kain') {
    include "kain/melihat_kain.php";
  }
   elseif (@$_GET['page'] == 'menambah_kain') {
    include "kain/menambah_kain.php";
  }
  elseif (@$_GET['page'] == 'mengubah_kain') {
    include "kain/mengubah_kain.php";
  }
  elseif (@$_GET['page'] == 'detail_kain') {
    include "detail_kain/melihat_detail_kain.php";
  }
   elseif (@$_GET['page'] == 'menambah_detail_kain') {
    include "detail_kain/menambah_detail_kain.php";
  }
  elseif (@$_GET['page'] == 'mengubah_detail_kain') {
    include "detail_kain/mengubah_detail_kain.php";
  }
  elseif (@$_GET['page'] == 'produksi') {
    include "produksi/melihat_produksi.php";
  }
   elseif (@$_GET['page'] == 'menambah_produksi') {
    include "produksi/menambah_produksi.php";
  }
  elseif (@$_GET['page'] == 'mengubah_produksi') {
    include "produksi/mengubah_produksi.php";
  }
  elseif (@$_GET['page'] == 'pengiriman') {
    include "pengiriman/melihat_pengiriman.php";
  }
   elseif (@$_GET['page'] == 'menambah_pengiriman') {
    include "pengiriman/menambah_pengiriman.php";
  }
  elseif (@$_GET['page'] == 'mengubah_pengiriman') {
    include "pengiriman/mengubah_pengiriman.php";
  }
   elseif (@$_GET['page'] == 'laporan') {
    include "laporan/melihat_laporan.php";
  }

  ?>
    <script src="../assets/bootstrap4/js/jquery-3.3.1.min.js"></script>
    <script src="../assets/bootstrap4/js/bootstrap.min.js"></script>
  </body>
</html>