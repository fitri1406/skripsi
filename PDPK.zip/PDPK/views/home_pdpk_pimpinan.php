<?php 
include_once "../models/+function.php";
require_once("../config/+koneksi.php");
require_once("../models/database.php");
$connection= new Database($host, $user, $pass, $database);
Cek_Login("pimpinan",$_SESSION['login'],$_SESSION['level']);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title> Aplikasi Pengolahan Data Hasil Produksi Kain </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../assets/bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  <body>

  <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <div class="row">
          <div class="col-sm-1 offset-1 mr-0"><img src="../assets/pic/logo 3m.JPG" class="rounded  logo" alt="logo"></div>
          <div class="col-sm"><h1 class="display-3">APLIKASI PENGOLAHAN DATA HASIL PRODUKSI KAIN <br>
          PT MULIA MEGAH MANDIRI</h1></div>
        </div>    
      </div>
  </div>
<nav class="navbar navbar-expand-lg navbar-light menu" style="background-color: #e3f2fd;">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav menu">
      <li class="nav-item active">
        <a class="nav-link" href="?page=home">Home <span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="?page=laporan">Melihat Laporan</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="?page=logout">Logout</a>
      </li>
    </ul>
  </div>
</nav>

<?php 
  if (@$_GET['page'] == 'home' or  @$_GET['page'] == '') {
     ?>
  <h1 align="center" class="selamat-datang"> Selamat Datang di Halaman Pimpinan</h1>
  <?php
      }

  elseif (@$_GET['page'] == 'laporan') {
    
    include "pimpinan/melihat_laporan.php";
  }
      else if (@$_GET['page'] == 'logout') {
                    echo "<script>
                      alert('Berhasil Logout, Terimakasih')
                      document.location.href='../index.php'
                    </script>"; 
                    $_SESSION=[];
                    session_unset();
                    session_destroy();             
                 }
  ?>
    <script src="../assets/bootstrap4/js/jquery-3.3.1.min.js"></script>
    <script src="../assets/bootstrap4/js/bootstrap.min.js"></script>
  </body>
</html>