<?php 
include_once "../models/+function.php";
include "../models/m_kain.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

$Kain = new Kain($connection);


?>



<div class="container view">

  <nav class="navbar justify-content-between mt-3">
 <span></span>
      <form method="POST" action="" class="form-inline text-right">
          <input class="form-control mr-sm-2" type="text" placeholder="Masukan Pencarian..." name="key" autofocus autocomplete="OFF" 
          value="<?php if (isset($_REQUEST['key'])) echo $_REQUEST['key'];  ?>">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="Cari">Cari</button>
     </form>
  </nav> 
    <table class="table table-striped">
    <thead>
      <tr>
        <th class="py-2">NO </th>
        <th class="py-2">ID Kain</th>
        <th class="py-2">Jenis Kain</th>
        <th class="py-2">Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  

    //pagination
    $JmlDataPerHalaman=5;
    $HalamanAktif= ( isset($_GET["p"]) ) ? $_GET["p"] : 1;
    $AwalData = ( $HalamanAktif - 1 ) * $JmlDataPerHalaman;
   
   // cari
     if (isset($_REQUEST['key']) AND $_REQUEST['key']<>"") {
      $key     = $_REQUEST['key'];
      $tampil=$Kain->Tampil_Kain($AwalData,$JmlDataPerHalaman,$key);
       $JmlData=mysqli_num_rows( $Kain->Tampil_Kain('','',$key) );  
          $no      = $AwalData+1; // no untuk di table
          $link    = "?page=kain&key=$key&p=";
          if (isset($_POST['Cari'])){ //untuk supaya page ada di no 1
            header("location:../views/home_pdpk.php?page=kain&key=$key&p=1");
          } // untk membuat key dapat terkirim lewat link
        }else{
          $tampil=$Kain->Tampil_Kain($AwalData,$JmlDataPerHalaman);
            $JmlData=mysqli_num_rows( $Kain->Tampil_Kain() ); 
          $no      = $AwalData+1; // no untuk di table
          $link    = "?page=kain&p=";
        }


    $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman);
    $p=( isset($_GET["p"]) ) ? $_GET["p"] : 1; 

    

    while ($data=$tampil->fetch_object()) {

     ?>
      <tr>
        <th scope="row"><?php echo $no; ?></th>
        <td><?php echo $data->Id_Kain; ?></td>
        <td><?php echo $data->Jenis_Kain; ?></td>
        <td>
          <a class="btn btn-primary" href="?page=mengubah_kain&ID=<?php echo $data->Id_Kain; ?>" role="button">Ubah</a> 
          <a class="btn btn-danger" href="?page=kain&ID=<?php echo $data->Id_Kain;?>&#Hapus">Hapus</a></td>
      </tr>  
      <?php 
      $no++;
      } ?>  
    </tbody>
  </table>


  <nav aria-label="..." class="nav">
     <ul class="pagination">
      <?php
         $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman); ?>
      <li class="page-item <?php $HalamanAktif < 2 ? disabled : ''; ?>">
          <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif-1; ?>" tabindex="-1">Previous</a>              
      </li>

       <?php
        $HalamanAktif > 3 ? "... &nbsp; " : "";
          for($i=$HalamanAktif-2;$i<$HalamanAktif;$i++):
              if ($i < 1 ) continue; { ?>
                <li class="page-item">
                  <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php 
              }
          endfor;
        ?> 

      <li class="page-item active">
        <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?><span class="sr-only">(current)</span></a>
      </li>

      <?php 
        for($i=$HalamanAktif+1;$i<($HalamanAktif+3);$i++){
            if($i > $JmlHalaman) break;?>
              <li class="page-item">
                <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
              </li>               
           <?php 
            }?>

        <li class="page-item <?php $HalamanAktif > $JmlHalaman-1 ? disabled : ''; ?>">
            <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif + 1; ?>">Next</a>
        </li>

    </ul>
    <a class="btn btn-secondary tambah" href="?page=menambah_kain" role="button">Tambah</a>
  </nav>

</div>


<!-- popup dalete -->
 <div class="container-fluid" id="Hapus">
        <div class="row justify-content-center">
        <div class="col-sm-5 hps">
              <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Menghapus Data</h5>
                <a href="?page=kain" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </a>
              </div>
              <div class="modal-body">

                <span> Apakah Anda Yakin Menghapus Data berikut:</span><br><br>
                <?php 
                $ID=$_GET['ID'];
                  $tampil=$Kain->Cari_Kain($ID);
                while ($data=$tampil->fetch_object()) {
                  $Id_Kain=$data->Id_Kain;  
                  $Jenis_Kain=$data->Jenis_Kain;        
                  }
                 ?>

                  <label>Id Kain</label><span>: <?php echo $Id_Kain; ?></span><br>
                  <label>Nama Kain</label><span>: <?php echo $Jenis_Kain; ?></span>

              </div>
              <div class="modal-footer">
                <form method="POST" action="">
                  <button type="submit" name="hapus_batal" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                  <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                </form>
              </div>
          </div>
        </div>
      </div>
      </div>


<?php 
    if (isset($_POST['hapus'])) {
      $Hapus=$Kain->Hapus_Kain($Id_Kain);
      $alert=Alert_Hapus($Hapus,'home_pdpk','kain');//$delete,$nama_file,$nama_page
      echo "$alert";
    }

    if (isset($_POST['hapus_batal'])) {
      echo Alert_Hapus_Batal();
    }


?>









