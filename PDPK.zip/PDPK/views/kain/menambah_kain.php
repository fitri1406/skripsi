<?php 
include_once "../models/+function.php";
include "../models/m_kain.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$Kain = new Kain($connection);
// $maxID=$Kain->Max_Id();
// $ID=Max_Id($maxID,1,5,'K');//$sql,$awal_char, $bnyk_char,$char-untuk

?>

<div class="container form-input">
  <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Menambah Data Kain</h4>
      <hr>
    </div>
  </div>
  <form method="POST" action="../models/proses_menambah_Kain.php">
    <div class="form-group row">
      <label for="Id_Kain" class="col-sm-2 offset-sm-3 col-form-label">Id Kain</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Kain" id="Id_Kain"  required>
      </div>
    </div>
    <div class="form-group row">
      <label for="Jenis_Kain" class="col-sm-2 offset-sm-3 col-form-label">Jenis Kain</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Jenis_Kain" id="Jenis_Kain" required>
      </div>

    </div>
    <div class="row tombol">
      <div class="col offset-sm-5">
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="reset" class="btn btn-danger" name="batal">Batal</button>
      </div>
       
    </div>

  </form>
</div>