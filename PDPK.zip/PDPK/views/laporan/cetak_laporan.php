<?php

include_once"../../models/+function.php";
require_once "../../config/+koneksi.php";
require_once"../../models/database.php";
require_once"../../assets//html2pdf/html2pdf.class.php";
include "../../models/m_laporan.php"; 
include "../../models/m_pengiriman.php";
include "../../models/m_produksi.php";
include "../../models/m_detail_kain.php";

$connection= new Database($host, $user, $pass, $database);
$Laporan = new Laporan($connection);
$Produksi = new Produksi($connection);
$Pengiriman = new Pengiriman($connection);
$Detail_Kain = new Detail_Kain($connection);

$key        = $_SESSION['key'];
$tgl_awal   = $_SESSION['tgl_awal'];
$tgl_akhir  = $_SESSION['tgl_akhir'];
$date=date('j-m-Y');

$source='
<style>
*{
	padding: 0; 
	margin: 0;

}
.container{
	
	width:770px;
	margin:10px auto;

}
.header-pdf{
	padding: 10px;
	text-align: center;
	font-size: 12px;
	border-bottom: 2px solid rgba(0,0,0,0.8);
	margin-bottom: 15px;
}

.conten-pdf{
	padding: 2px;
}

.conten-pdf-header{
	margin-bottom: 10px;
}
.conten-pdf-header h2{
	text-align: center;
	margin-bottom: 15px;
}

.conten-pdf-header p{
	font-size: 15px;
	padding: 3px;
}
.conten-table-pdf{
	text-align: center;
	padding: 10px;
}

.conten-table-pdf table{
	border: 1px solid black;
	border-radius: 2px;
	margin: auto;
	margin-top: 40px;
	font-size: 14px;
}

.conten-table-pdf table th{
	text-align: center;
	padding: 3px 4px;
	background-color: #ddd;
}

.conten-table-pdf table td{
	text-align: center;
	padding: 8px;
}


.conten-table-pdf table tr:nth-child(odd){
	background-color: red;
}

</style> ';

$source .= '
<page>
	<div class="container">
		<div class="header-pdf">
		<h1>Aplikasi Pengolahan Data Hasil Produksi Kain <br>
		PT. Mulia Megah Mandiri</h1>	

		</div>

		<div class="conten-pdf">
			<div class="conten-pdf-header">
				<h2>Laporan Rekap Hasil Produksi dan Pengiriman </h2>
				<p>Tanggal :'.$date.'</p>

			</div>

			<div class="conten-table-pdf">
				<table width=>
					<tr>
						<th>NO</th>
						<th>Nama Customer</th>
						<th>Id Kain</th>
						<th>Produksi</th>
						<th>Pengiriman</th>
						<th>Stok</th>
					
					</tr>';
					$no=1;

					$Tampil_Laporan= $Laporan->Melihat_Laporan('','','','','','group');
					if($key!=NULl AND $tgl_awal==NULL){
						$Tampil_Laporan= $Laporan->Melihat_Laporan($key);
					}
					 else if ($key!=NULl AND $tgl_awal!=NULL) {
						$Tampil_Laporan= $Laporan->Melihat_Laporan($key,$tgl_awal,$tgl_akhir);
					}
					elseif ($key==NULl AND $tgl_awal!=NULL) {
						$Tampil_Laporan= $Laporan->Melihat_Laporan('',$tgl_awal,$tgl_akhir,'1','1','group');
					}
					
          			while ( $data=$Tampil_Laporan->fetch_object() )  {

     					$Stok=$data->Total_Produksi - $data->Total_Pengiriman;

			$source.= '<tr>
						<td>'.$no++.'.</td>
						<td>'.$data->Nama_Customer.'</td>
						<td>'.$data->Id_Kain.'</td>
						<td>'.$data->Total_Produksi.'</td>
						<td>'.$data->Total_Pengiriman.'</td>
						<td>'.$Stok.'</td>
				
				</tr>';
					 }

		$source.='</table>
			</div>
		</div>
	</div>
</page>';

$html2pdf = new HTML2PDF('P', 'A4', 'en');
$html2pdf->setDefaultFont('Arial');
$html2pdf->writeHTML($source);
$html2pdf->Output('Pekerjaan - '.rand().'.pdf');

?>