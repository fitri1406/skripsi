<?php 
include_once "../models/+function.php";
include "../models/m_laporan.php";
include "../models/m_pengiriman.php";
include "../models/m_produksi.php";
include "../models/m_detail_kain.php";

ob_start();
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);

$Laporan = new Laporan($connection);
$Produksi = new Produksi($connection);
$Pengiriman = new Pengiriman($connection);
$Detail_Kain = new Detail_Kain($connection);
$Data_Laporan = $Laporan->Melihat_Laporan('','','','','','group');

$nm_cust= ( isset($_REQUEST["key"]) ) ? $_REQUEST["key"] : null;
Hapus_Session();
?>
<div class="container view">
  <!-- row cari -->
  <div class="row row-form-cari p-3  ">
    <div class="col border-bottom-0 border-secondary rounded p-2">
      <form action="" method="POST" name="Form-cari-laporan">
        <div class="form-group row mb-0">
          <label for="key" class="col-sm-1 col-form-label">Customer</label>
            <div class="col-sm-3">
              <select class="custom-select" name="key" id="key" >
                <option value=""> -- Silahkan Pilih  -- </option>
                  <?php 
                  while ($data=$Data_Laporan->fetch_object()) :            
                  ?>
                 <option value="<?php echo $data->Id_Detail_Kain; ?>"

                   <?php
                    if ($nm_cust==$data->Id_Detail_Kain): 
                      echo "selected";
                    endif 
                    ?> >
                <?php echo "$data->Id_Detail_Kain | $data->Nama_Customer"; ?>
                  
                  </option> 
                <?php 
                endwhile;
                ?>
              </select>

            </div>
          <label for="Periode" class="col-sm-1 col-form-label">||</label> 
          <label for="Periode" class="col-sm-1 col-form-label">Periode</label>
            <div class="col-sm-2 p-0">
              <input type="date" name="Tanggal_Awal" class="form-control" id="Tanggal_Awal">
            </div>
            <label for="s/d" class="col-sm-1 col-form-label text-center">s/d</label>
            <div class="col-sm-2 mb-1 p-0">
              <input type="date" name="Tanggal_Akhir" class="form-control" id="Tanggal_Akhir">
            </div>
            <div class="col-sm-1 text-md-right p-1">
              <button type="submit" class="btn btn-outline-primary w-100 p-1" name="Cari">Cari</button>    
            </div>
        </div>
      </form>
    </div>
  </div>
  <table class="table table-striped">
    <thead>
      <tr>
        <th class="py-2">NO </th>
        <th class="py-2">ID Detail </th>
        <th class="py-2">Nama Customer</th>
        <th class="py-2">ID Kain</th>
        <th class="py-2">Produksi</th>
        <th class="py-2">Pengiriman</th>
        <th class="py-2">Stok</th>
      </tr>
    </thead>
    <tbody>
    <?php 
          $JmlDataPerHalaman = 5;
          $HalamanAktif      = ( isset($_GET["p"]) ) ? $_GET["p"] : 1;
          $AwalData          = ( $HalamanAktif - 1 ) * $JmlDataPerHalaman;

        if ( (isset($_REQUEST['key']) AND $_REQUEST['key']<>"") OR 
           (isset($_REQUEST['Tanggal_Awal']) AND $_REQUEST['Tanggal_Awal']<>"") OR 
           (isset($_REQUEST['Tanggal_Akhir']) AND $_REQUEST['Tanggal_Akhir']<>"")  )  { 
          $key       = $_REQUEST['key'];
          $tgl_awal  = $_REQUEST['Tanggal_Awal'];
          $tgl_akhir = $_REQUEST['Tanggal_Akhir'];
          if ( $tgl_awal>$tgl_akhir ) {
            echo "<script>
                      alert('format tanggal salah !!')
                      document.location.href='../views/home_pdpk.php?page=laporan'
                  </script>";
                  die();
          }

          $Tampil_Laporan= $Laporan->Melihat_Laporan($key,$tgl_awal,$tgl_akhir,$AwalData,
                              $JmlDataPerHalaman);
           $JmlData = mysqli_num_rows($Laporan->Melihat_Laporan($key,$tgl_awal,$tgl_akhir,'',''));
          $_SESSION['key']       = $key;
          $_SESSION['tgl_awal']  = $tgl_awal;
          $_SESSION['tgl_akhir'] = $tgl_akhir;
          $no           = $AwalData+1;
          $link         = "?page=laporan&key=$key&Tanggal_Awal=$tgl_awal&Tanggal_Akhir=$tgl_akhir&p=";
          if ($_SESSION['tgl_awal']!=null) {
         $Tampil_Laporan= $Laporan->Melihat_Laporan($key,$tgl_awal,$tgl_akhir,$AwalData,
                              $JmlDataPerHalaman,'group');
          }

          if (isset($_POST['Cari'])){ 

            header("location:../views/home_pdpk.php?page=laporan&key=$key&Tanggal_Awal=$tgl_awal&Tanggal_Akhir=$tgl_akhir&p=1");
          } 
         
        }else{
          $Tampil_Laporan= $Laporan->Melihat_Laporan('','','',$AwalData,
                              $JmlDataPerHalaman,'group');
           $JmlData = mysqli_num_rows($Laporan->Melihat_Laporan('','','','','','group'));

          $no      = $AwalData+1;
          $link    = "?page=laporan&p=";
        }

      $p =  isset($_GET["p"]) ? $_GET["p"] : 1;

      while ($data = $Tampil_Laporan->fetch_object()) {
          
     $Stok=($data->Total_Produksi)-($data->Total_Pengiriman);
     ?>

      <tr>
        <th scope="row" class="p-2"><?php echo "$no."; ?></th>
        <td class="p-2"><?php echo $data->Id_Detail_Kain; ?></td>
        <td class="p-2"><?php echo $data->Nama_Customer; ?></td>
        <td class="p-2"><?php echo $data->Id_Kain; ?></td>
        <td class="p-2"><?php echo $data->Total_Produksi; ?></td>
        <td class="p-2"><?php echo $data->Total_Pengiriman; ?></td>
        <td class="p-2"><?php echo $Stok; ?></td>
      </tr>
      <?php 
      $no++;
      } ?>  
    </tbody>
  </table>
 <nav aria-label="..." class="nav">
    <ul class="pagination">
      <?php
         $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman); ?>
      <li class="page-item <?php $HalamanAktif < 2 ? disabled : ''; ?>">
          <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif-1; ?>" tabindex="-1">Previous</a>              
      </li>

       <?php
        $HalamanAktif > 3 ? "... &nbsp; " : "";
          for($i=$HalamanAktif-2;$i<$HalamanAktif;$i++):
              if ($i < 1 ) continue; { ?>
                <li class="page-item">
                  <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php 
              }
          endfor;
        ?> 

      <li class="page-item active">
        <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?><span class="sr-only">(current)</span></a>
      </li>

      <?php 
        for($i=$HalamanAktif+1;$i<($HalamanAktif+3);$i++){
            if($i > $JmlHalaman) break;?>
              <li class="page-item">
                <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
              </li>               
           <?php 
            }?>

        <li class="page-item <?php $HalamanAktif > $JmlHalaman-1 ? disabled : ''; ?>">
            <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif + 1; ?>">Next</a>
        </li>

    </ul>
    <a class="btn btn-secondary tambah" href="laporan/cetak_laporan.php" role="button" target="_blank">Cetak</a>
  </nav>

</div>
<script type="text/javascript">
  const tgl_awal  = document.querySelector('#Tanggal_Awal');
  const tgl_akhir = document.querySelector('#Tanggal_Akhir');
  tgl_awal.addEventListener('input', function(){
    var value = tgl_awal.value;
    if (value != '') {
      tgl_akhir.setAttribute('required','required');
    }
  })
</script>