<?php 
include_once "../models/+function.php";
include "../models/m_pengiriman.php";
include "../models/m_detail_kain.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$Pengiriman = new Pengiriman($connection);
$Detail_Kain = new Detail_Kain($connection);
$Cek_Detail_Kain = $Detail_Kain->Cari_Detail_Kain2('','order');
$maxID=$Pengiriman->Max_Id();
$ID=Max_Id($maxID,2,5,'PG');
?>

<div class="container form-input">
  <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Menambah Data Pengiriman</h4>
      <hr>
    </div>
  </div>
  <form method="POST" action="../models/proses_menambah_pengiriman.php">
    <div class="form-group row ">
      <label for="Tgl_Pengiriman" class="col-sm-2 offset-sm-3 col-form-label">Tanggal Pengiriman</label>
      <div class="col-sm-4">
       <input type="date" class="form-control" id="Tgl_Pengiriman" name="Tgl_Pengiriman" required>
      </div>
    </div>
    <div class="form-group row">
      <label for="Id_Pengiriman" class="col-sm-2 offset-sm-3 col-form-label">Id Pengiriman</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Pengiriman" id="Id_Pengiriman" value="<?php echo "$ID"; ?>" required>
      </div>
    </div>

    <div class="form-group row">
        <label for="Id_Detail_Kain" class="col-sm-2 offset-sm-3 col-form-label ">ID Detail Kain</label>
            <div class="col-sm-4">
              <select class="custom-select" name="Id_Detail_Kain" id="Id_Detail_Kain" required  onchange="changeValue(this.value)">
              <option value=""> -- Silahkan Pilih  -- </option>
                <?php
                  $jsArray = "var js_produksi = new Array();\n";
                 while ($data_detail_kain=$Cek_Detail_Kain->fetch_object()) :
                ?>
              <option value="<?php echo $data_detail_kain->Id_Detail_Kain;
              ?>"><?php 
                   echo $data_detail_kain->Id_Detail_Kain; echo " | ";
                   echo $data_detail_kain->Id_Kain; echo " | ";
                   echo $data_detail_kain->Nama_Customer; 
                   ?>
              </option>
                <?php 
                $jsArray .= "js_produksi['" .$data_detail_kain->Id_Detail_Kain . "'] = {nama_customer:'" .
                addslashes($data_detail_kain->Nama_Customer) . "',Id_kain:'".
                addslashes($data_detail_kain->Id_Kain)."'};\n";
                endwhile;
                ?>
            </select>
            </div>            
        </div>

         <div class="form-group row">
          <label for="Nama_Customer" class="col-sm-2 offset-sm-3 col-form-label">Nama Customer</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="Nama_Customer" id="Nama_Customer" readonly required>
          </div>
        </div>

         <div class="form-group row">
          <label for="Id_Kain" class="col-sm-2 offset-sm-3 col-form-label">Id Kain</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="Id_Kain" id="Id_Kain"  readonly required>
          </div>
        </div>

        <div class="form-group row">
          <label for="Jml_Pengiriman" class="col-sm-2 offset-sm-3 col-form-label">Jml Pengiriman</label>
          <div class="col-sm-4">
            <input type="number" class="form-control" name="Jml_Pengiriman" id="Jml_Pengiriman" required>
          </div>
        </div>

    </div>
    <div class="row tombol">
      <div class="col offset-sm-5">
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="reset" class="btn btn-danger" name="batal">Batal</button>
      </div>
       
    </div>

  </form>
</div>
<script type="text/javascript">
  <?php echo $jsArray;  ?>
  function changeValue(no){
    document.getElementById('Nama_Customer').value = js_produksi[no].nama_customer; 
    document.getElementById('Id_Kain').value   = js_produksi[no].Id_kain;
   
  }; 
</script>