<?php 
include_once"../models/+function.php";
include "../models/m_produksi.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$Produksi = new Produksi($connection);
$data_cust= $Produksi->Tampil_Produksi('','','','','grup');
ob_start();

$nm_cust= ( isset($_REQUEST["key"]) ) ? $_REQUEST["key"] : null;
?>
<div class="container view">
  <nav class="navbar justify-content-between mt-3">
    <span></span>
      <form method="POST" action="" class="form-inline text-right">
      <label id="key" class="mr-5">Nama Customer</label>
          <select class="custom-select" name="key" id="key" >
                     
           <option value="">  -- Silahkan Pilih  -- </option>

            <?php 
              while ($data=$data_cust->fetch_object()) :            
              ?>
                <option value="<?php echo $data->Nama_Customer; ?>"

                 <?php
                  if ($nm_cust==$data->Nama_Customer): 
                    echo "selected";
                  endif 
                  ?> >
              <?php echo $data->Nama_Customer; ?>
                
                </option> 
              <?php 
              endwhile;
              ?>             
          </select>
         
        <button class="btn btn-success my-2 my-sm-0 " type="submit" name="Cari">Cari</button>
     </form>
  </nav>

    <table class="table table-striped">
    <thead>
      <tr>
        <th class="py-2">NO </th>
        <th class="py-2">Nama Customer</th>
        <th class="py-2">ID Kain</th>
        <th class="py-2">Tanggal Produksi</th>
        <!-- <th class="py-2">Nama Customer</th> -->
        <th class="py-2 text-center">Jumlah Produksi</th>
        <th class="py-2">Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    
    $JmlDataPerHalaman=5;
    $HalamanAktif= ( isset($_GET["p"]) ) ? $_GET["p"] : 1;
    $AwalData = ( $HalamanAktif - 1 ) * $JmlDataPerHalaman;

    if (isset($_REQUEST['key']) AND $_REQUEST['key']<>"") {
      $key     = $_REQUEST['key'];
      $tampil=$Produksi->Tampil_Produksi($AwalData,$JmlDataPerHalaman,'',$key);
       $JmlData=mysqli_num_rows( $Produksi->Tampil_Produksi('','','',$key) );  
          $no      = $AwalData+1;
          $link    = "?page=produksi&key=$key&p=";
          if (isset($_POST['Cari'])){ 
            header("location:../views/home_pdpk.php?page=produksi&key=$key&p=1");
          } 
        }else{
          $tampil=$Produksi->Tampil_Produksi($AwalData,$JmlDataPerHalaman);
            $JmlData=mysqli_num_rows( $Produksi->Tampil_Produksi() ); 
          $no      = $AwalData+1; 
          $link    = "?page=produksi&p=";
        }
    
    $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman);
    $p=( isset($_GET["p"]) ) ? $_GET["p"] : 1; 

    while ($data=$tampil->fetch_object()) {

     ?>
      <tr>
        <th scope="row"><?php echo $no; ?></th>
        <td><?php echo $data->Nama_Customer; ?></td>
        <td><?php echo $data->Id_Kain; ?></td>
        <td><?php echo $data->Tgl_Produksi; ?></td>
        <td class="text-center"><?php echo $data->Jml_Produksi; ?></td>  
        <td>
          <a class="btn btn-primary" href="?page=mengubah_produksi&ID=<?php echo $data->Id_Produksi; ?>" role="button">Ubah</a> 
          <a class="btn btn-danger" href="?page=produksi&ID=<?php echo $data->Id_Produksi;?>&#Hapus">Hapus</a></td>
      </tr>  
      <?php 
      $no++;
      } ?>  
    </tbody>
  </table>
  <nav aria-label="..." class="nav">
   <ul class="pagination">
      <?php
         $JmlHalaman=ceil($JmlData / $JmlDataPerHalaman); ?>
      <li class="page-item <?php $HalamanAktif < 2 ? disabled : ''; ?>">
          <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif-1; ?>" tabindex="-1">Previous</a>              
      </li>

       <?php
        $HalamanAktif > 3 ? "... &nbsp; " : "";
          for($i=$HalamanAktif-2;$i<$HalamanAktif;$i++):
              if ($i < 1 ) continue; { ?>
                <li class="page-item">
                  <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php 
              }
          endfor;
        ?> 

      <li class="page-item active">
        <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?><span class="sr-only">(current)</span></a>
      </li>

      <?php 
        for($i=$HalamanAktif+1;$i<($HalamanAktif+3);$i++){
            if($i > $JmlHalaman) break;?>
              <li class="page-item">
                <a class="page-link" href="<?php echo $link ?><?php echo $i; ?>"><?php echo $i; ?></a>
              </li>               
           <?php 
            }?>

        <li class="page-item <?php $HalamanAktif > $JmlHalaman-1 ? disabled : ''; ?>">
            <a class="page-link" href="<?php echo $link ?><?php echo $HalamanAktif + 1; ?>">Next</a>
        </li>

    </ul>
    <a class="btn btn-secondary tambah" href="?page=menambah_produksi" role="button">Tambah</a>
  </nav>

</div>
 <div class="container-fluid" id="Hapus">
        <div class="row justify-content-center">
        <div class="col-sm-5 hps">
              <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Menghapus Data</h5>
                <a href="?page=produksi" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </a>
              </div>
              <div class="modal-body">

                <span> Apakah Anda Yakin Menghapus Data berikut:</span><br><br>
                <?php 
                $ID=$_GET['ID'];
                  $tampil=$Produksi->Cari_Produksi($ID);
                while ($data=$tampil->fetch_object()) {
                  $Id_Produksi=$data->Id_Produksi;  
                  $Id_Detail_Kain=$data->Id_Detail_Kain;        
                  }
                 ?>

                  <label>Id Detail Kain</label><span>: <?php echo $Id_Produksi; ?></span><br>
                  <label>Id Kain</label><span>: <?php echo $Id_Detail_Kain; ?></span>

              </div>
              <div class="modal-footer">
                <form method="POST" action="">
                  <button type="submit" name="hapus_batal" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                  <button type="submit" name="hapus" class="btn btn-danger">Hapus</button>
                </form>
              </div>
          </div>
        </div>
      </div>
      </div>
<?php 
    if (isset($_POST['hapus'])) {
      $Hapus=$Produksi->Hapus_Produksi($Id_Produksi);
      $alert=Alert_Hapus($Hapus,'home_pdpk','produksi');
      echo "$alert";
    }

    if (isset($_POST['hapus_batal'])) {
      echo Alert_Hapus_Batal();
    }
?>









