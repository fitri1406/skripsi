<?php 
include_once"../models/+function.php";
include "../models/m_produksi.php";
include "../models/m_detail_kain.php";
Cek_Login("admin",$_SESSION['login'],$_SESSION['level']);
$Produksi = new Produksi($connection);
$Detail_Kain = new Detail_Kain($connection);
$id=$_GET['ID'];
$sql=$Produksi->Tampil_Produksi('','',$id);
$Cek_Detail_Kain=$Detail_Kain->Cari_Detail_Kain2('','order');

while ($data=$sql->fetch_object()) {
		$Id_Produksi=$data->Id_Produksi;	
    $Id_Detail_Kain=$data->Id_Detail_Kain;
 		$Tgl_Produksi=$data->Tgl_Produksi;
    $Jml_Produksi = $data->Jml_Produksi;
    $Nama_Customer = $data->Nama_Customer;
    $Id_Kain = $data->Id_Kain;
	}
?>
<div class="container form-input">
  <form method="POST" action="">
   <div class="row header-form">
    <div class="col-sm-5 offset-sm-4 text-center">
      <h4>Halaman Mengubah Data Produksi</h4>
      <hr>
    </div>
  </div>
    <div class="form-group row ">
      <label for="Tgl_Produksi" class="col-sm-2 offset-sm-3 col-form-label">Tanggal Pekerjaan</label>
      <div class="col-sm-4">
       <input type="date" class="form-control" id="Tgl_Produksi" name="Tgl_Produksi" value="<?php echo"$Tgl_Produksi"; ?>"    required>
      </div>
    </div>
    <div class="form-group row">
      <label for="Id_Produksi" class="col-sm-2 offset-sm-3 col-form-label">Id Produksi</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" name="Id_Produksi" id="Id_Produksi" value="<?php echo "$id"; ?>" required>
      </div>
    </div>
      <div class="form-group row">
        <label for="Id_Detail_Kain" class="col-sm-2 offset-sm-3 col-form-label ">ID Detail Kain</label>
            <div class="col-sm-4">
              <select class="custom-select" name="Id_Detail_Kain" id="Id_Detail_Kain" required  onchange="changeValue(this.value)">
            <option value=""> -- Silahkan Pilih  -- </option>
              <?php 
              $jsArray = "var js_produksi = new Array();\n";//menyisipkan script array javascript ke php
              while ($data_detail_kain=$Cek_Detail_Kain->fetch_object()) :            
              ?>
            <option value="<?php echo $data_detail_kain->Id_Detail_Kain;?>" 
                <?php 
                  if ($data_detail_kain->Id_Detail_Kain==$Id_Detail_Kain) { echo "selected=\"selected\"";}
                ?> ><?php echo "$data_detail_kain->Id_Detail_Kain";?>  
            </option>
              <?php 
                $jsArray .= "js_produksi['" .$data_detail_kain->Id_Detail_Kain . "'] = {nama_customer:'" .
                addslashes($data_detail_kain->Nama_Customer) . "',Id_kain:'".
                addslashes($data_detail_kain->Id_Kain)."'};\n";
              endwhile;
              ?>
          </select>
            </div>            
        </div>
        <div class="form-group row">
          <label for="Nama_Customer" class="col-sm-2 offset-sm-3 col-form-label">Nama Customer</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="Nama_Customer" id="Nama_Customer" value="<?php echo"$Nama_Customer"; ?>" readonly required>
          </div>
        </div>

         <div class="form-group row">
          <label for="Id_Kain" class="col-sm-2 offset-sm-3 col-form-label">Id Kain</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="Id_Kain" id="Id_Kain"  value="<?php echo"$Id_Kain"; ?>" readonly required>
          </div>
        </div>
      <div class="form-group row">
          <label for="Jml_Produksi" class="col-sm-2 offset-sm-3 col-form-label">Jml Produksi</label>
          <div class="col-sm-4">
            <input type="number" class="form-control" name="Jml_Produksi" id="Jml_Produksi" value="<?php echo"$Jml_Produksi"; ?>" required>
          </div>
        </div>

    </div>
    <div class="row tombol">
        <div class="col offset-sm-5">
          <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
          <button type="reset" class="btn btn-danger" name="batal">Batal</button>
        </div>
    </div>

  </form>
</div>

<script type="text/javascript">
  <?php echo $jsArray;  ?>
  function changeValue(no){
    document.getElementById('Nama_Customer').value = js_produksi[no].nama_customer; 
    document.getElementById('Id_Kain').value   = js_produksi[no].Id_kain;
  }; 
</script>

<?php 
if (isset($_POST['simpan'])) {
	
	  $Tgl_Produksi=$connection->conn->real_escape_string($_POST['Tgl_Produksi']);
    $Id_Produksi=$connection->conn->real_escape_string($_POST['Id_Produksi']);
    $Id_Detail_Kain=$connection->conn->real_escape_string($_POST['Id_Detail_Kain']);
    $Jml_Produksi=$connection->conn->real_escape_string($_POST['Jml_Produksi']);
   
 
    $update=$Produksi->Update_Produksi($Id_Produksi,$Id_Detail_Kain,$Tgl_Produksi,$Jml_Produksi);
    if ($update>0){
		echo "<script>
		     	alert('Data berhasil di Update!!')
		       	document.location.href='home_pdpk.php?page=produksi'
		      </script>";
	}else{
		echo "<script>
	           	alert('Data Gagal di Update!!')
	           	document.location.href='home_pdpk.php?page=mengubah_produksi&ID=$Id_Produksi'
	          </script>";
	}
}

 ?>